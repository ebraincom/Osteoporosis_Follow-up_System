<template>
  <div class="patient-info-page">
    <h2>患者信息管理</h2>
    <p>管理患者的基本信息和医疗数据</p>
  </div>
</template>

<script setup lang="ts">
// 患者信息页面逻辑
</script>

<style scoped>
.patient-info-page {
  padding: 20px;
}
</style> 