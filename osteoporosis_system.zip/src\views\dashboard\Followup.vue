<template>
  <div class="followup-page">
    <h2>随访管理</h2>
    <p>管理患者的随访计划和提醒</p>
  </div>
</template>

<script setup lang="ts">
// 随访管理页面逻辑
</script>

<style scoped>
.followup-page {
  padding: 20px;
}
</style> 